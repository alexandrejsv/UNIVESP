can dog tfb.ttf is a free for personal use ..... =)

Is a dingbats of silhouettes of dog's



Direct link to the font http://truefonts.blogspot.com/2012/11/can-dog-dingbats.html


Thanks for download
Gracias por descargar


my site: http://truefonts.blogspot.com

Kaiserzharkhan - Chile